let chooseOperator = prompt(`Hello, please choose the operation: \r\n 
(+, -, /, *, %, cos, sin, pow)`);
let firstNum, secondNum, trigonomNum;

if (chooseOperator == '+' || chooseOperator == '-' || chooseOperator ==
    '/' || chooseOperator == '*' || chooseOperator == '%' || chooseOperator == 'pow') {
    firstNum = +prompt(`Give the first number: `);
    secondNum = +prompt(`Give the second number: `);
} else if (chooseOperator == 'sin' || chooseOperator == 'cos') {
    trigonomNum = +prompt(`Give the number: `);
} else {
    alert('Wrong input, please start again!');
    location.reload();
}

if (chooseOperator == '+') {
    const sumNum = firstNum + secondNum;
    alert(sumNum);
} else if (chooseOperator == '-') {
    const negNum = firstNum - secondNum;
    alert(negNum);
} else if (chooseOperator == '/') {
    const devNum = firstNum / secondNum;
    alert(devNum);
} else if (chooseOperator == '*') {
    const multNum = firstNum * secondNum;
    alert(multNum);
} else if (chooseOperator == '%') {
    const chunkNum = firstNum % secondNum;
    alert(chunkNum);
} else if (chooseOperator == 'sin') {
    const sinNum = Math.sin(trigonomNum);
    alert(sinNum);
} else if (chooseOperator == 'cos') {
    const cosNum = Math.cos(trigonomNum);
    alert(cosNum);
} else if (chooseOperator == 'pow') {
    const powNum = Math.pow(firstNum, secondNum);
    alert(powNum);
}